////////////INICIALIZAÇÃO
window.addEventListener('DOMContentLoaded', () => {
  const secoes = document.querySelectorAll('.secao');
  const links = document.querySelectorAll('.menu-vertical a');

  ////////////TROCA DE SEÇÃO
  function mostrarSecao(id) {
    secoes.forEach(secao => {
      secao.classList.remove('ativa');
    });

    const secaoAtiva = document.getElementById(id);
    if (secaoAtiva) {
      secaoAtiva.classList.add('ativa');
    }
  }

  ////////////ATUALIZA SEÇÃO
  function atualizarHash() {
    const hash = window.location.hash.replace('#', '') || 'sobre';
    mostrarSecao(hash);
  }

  ////////////NAVEGAÇÃO PELO MENU LATERAL
  links.forEach(link => {
    link.addEventListener('click', e => {
      e.preventDefault();
      const destino = link.getAttribute('href').substring(1);
      window.location.hash = destino;
    });
  });

  window.addEventListener('hashchange', atualizarHash);
  atualizarHash();

  ////////////ENVIO DO FORMULÁRIO
  const form = document.getElementById('form-contato');
  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      alert('Mensagem enviada!');
      form.reset();
    });
  }
});
